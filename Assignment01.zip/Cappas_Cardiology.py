# Δήλωση των βιβλιοθήκων.
import math
import openpyxl
import random
import numpy as np

# Βασικές μεταβλητές ανοίγματος του αρχείου
wb = openpyxl.load_workbook(r'c:Cardiology.xlsx')
sheet = wb.active
a = 65
healthy = 'healthy'
sick = 'sick'
outclass = 13

# Άνοιγμα του αρχείου προς εξέταση και αποθήκευση της πρώτης γραμμής στον πίνακα CRRAY
CRRAY = []
f = 1
index = 0
while True:
    b = chr(a + index)
    c = str(f)
    d = b + c
    x1 = sheet[d].value
    if x1 == None:
        break
    CRRAY.append(x1)
    index += 1
number_of_cols = index

# Άνοιγμα του αρχείου προς εξέταση και αποθήκευση του περιεχομένου του στον πίνακα ARRAY
e = 0
ARRAY = []
for index in range(0, number_of_cols):
    b = chr(a)
    i = 2
    ROW = []
    while True:
        if i > 0:
            c = str(i)
            d = b + c
            x1 = sheet[d].value
            if x1 == None:
                e = 1
                break
            ROW.append(x1)
        i = i + 1
    ARRAY.append(ROW)
    a = a + 1
i = i - 2

# Αποθήκευση του πίνακα ARRAY στον BRRAY και ξανά στον ARRAY για καθαρότερο διάβασμα
BRRAY = []
for row in range(0, i):
    ROW = []
    for col in range (0, number_of_cols):
        ROW.append(ARRAY[col][row])
    BRRAY.append(ROW)
ARRAY = BRRAY

# Ταξινόμηση του πίκακα ARRAY ως προς την κλάση εξόδου
for row in range(0, i):
    for col in range(0, row+1):
        if ARRAY[row][outclass] < ARRAY[col][outclass]:
            temp = ARRAY[row]
            ARRAY[row] = ARRAY[col]
            ARRAY[col] = temp

# Αποθήκευση του πίνακα ARRAY σε 2 πίνακες, ο ένας πίνακας περιέχει το healthy Και ο άλλαος τον sick     
hARRAY = []
sARRAY = []
j = 0
k = 0
for row in ARRAY:
    if row[outclass] == healthy:
        hARRAY.append(row)
        j += 1
    if row[outclass] == sick:
        k += 1
        sARRAY.append(row)

# Εμφάνιση της αναλογίας της κλάσης εξόδου της ARRAY   
llg = 35 * (j / (k + j))
print("Η αναλογία υγιούς με άρρωστου ασθεσνή στο αρχικό αρχείο είναι", llg*100/35, "%")
llg = math.floor(llg)

# Αντιγραφή του 75% του ARRAY στον BRRAY με την ίδια αναλογία της κλάσης εξόδου του ARRAY
BRRAY = []
jj = 0
kk = 0
i = math.ceil(i * 0.75)
for row in range(0, i):
    if row % 35 >= 0 and row % 35 < llg and jj <= j:
        if jj < j:
            BRRAY.append(hARRAY[jj])
            hARRAY[jj] = []
        jj += 1
    if row % 35 >= llg and row % 35 < 35:
        if kk < k:
            BRRAY.append(sARRAY[kk])
            sARRAY[kk] = []
        kk += 1

# Εμφάνιση της αναλογίας της κλάσης εξόδου της BRRAY (σύνολο εκπαίδευσης)          
j = 0
k = 0
llll = 0
print("Ο πίνακας εκπαίδευσης είναι:")
for row in BRRAY:
    print(llll, row)
    if row[outclass] == healthy:
        j += 1
    if row[outclass] == sick:
        k += 1
    llll += 1
llg = 100 * (j / (k + j))
print()
print("Η αναλογία υγιούς με άρρωστου ασθεσνή στο δείγμα της εκπαίδευσης είναι", llg, "%")  
COLL = []

# Υπολογισμός της Info της κλάσης εξόδου
for rrr in range(0, number_of_cols - 1):
    # Αρχικοπόηση των πινάκων μετρικών και διακλαδώσεως του δένδρου
    HEALTH = []
    HEALTHH = []
    SICK = []
    SICKK = []
    GAINRATIO = []
    RATIO = []
    COL = []
    i = i - 1
    
    # Υπολογισμός του Info την κλάσης εξόδου
    healthycount = 0
    sickcount = 0
    for row in BRRAY:
        if row[outclass] == healthy:
            healthycount += 1
        if row[outclass] == sick:
            sickcount += 1
    healthyinfo = healthycount / (i+1)
    sickinfo = sickcount / (i+1)
    info = -(healthyinfo * math.log(healthyinfo, 2) + sickinfo * math.log(sickinfo, 2))
    
    # Μέθοδος ταξινόμησης πίνακα με βάση την κλάση εισόδου σε αύξουσα σειρά
    def ARRAY_SORT(BRRAY, index, i):
        for row in range(0, i+1):
            for col in range(0, row+1):
                if BRRAY[row][index] < BRRAY[col][index]:
                    temp = BRRAY[row]
                    BRRAY[row] = BRRAY[col]
                    BRRAY[col] = temp
        
    # Μέθοδος ταξινόμησης της κλάσης εξόδου κατά φθίνουσα σειρά εάν υπάρχουν διαφορετικές τιμές
    # εξόδου στην ίδια τιμή κλάσης εισόδου
    def SORT_ARRAY(BRRAY, index, i):
        flag = 0
        for row in range(0, i+1):
            if BRRAY[row][index] == BRRAY[row - 1][index]:
                if BRRAY[row][outclass] == healthy and BRRAY[row - 1][outclass] == sick:
                    temp = BRRAY[row]
                    BRRAY[row] = BRRAY[row - 1]
                    BRRAY[row - 1] = temp
                flag = 1
            if BRRAY[row][index] != BRRAY[row - 1][index] and flag == 1:
                if BRRAY[row][outclass] == healthy and BRRAY[row- 1][outclass] == sick:
                    temp = BRRAY[row]
                    BRRAY[row] = BRRAY[row - 1]
                    BRRAY[row - 1] = temp
                flag = 0

    # Σύγκριση της κλάσης εξόδου με τις κλάσεις εισόδου
    for col in range(0, number_of_cols):
        # Ελέγχουμε ότι καμία κλάση εισόδου δεν είναι η κλάση εξόδου ή κλάση ρίζα
        if col not in COLL and col != outclass:
            # Ταξινόμηση πίνακα και αρχικοποίηση μεταβλητών διακλάδωσης.
            ARRAY_SORT(BRRAY, col, i)
            SORT_ARRAY(BRRAY, col, i)
            ARRAY_SORT(BRRAY, col, i)
            healthycount1 = 0
            sickcount1 = 0
            info3 = 0
            splitinfo = 0
            
            # Έλεγχος εάν η κλάση εισόδου είναι αριθμός ή συμβολοσειρά.
            flag = BRRAY[1][col]
            if isinstance(flag, int) == True and col != 11 or isinstance(flag, float) == True and col != 1: # Αριθμητική περίπτωση
                healthsick = 0
                maxhealth = 0
                breakpoint = 0

                # Εύρεση της διακλάδωσης του δένδρου
                for row in BRRAY:
                    if row[outclass] == healthy:
                        healthsick += 1
                    if row[outclass] == sick:
                        healthsick -= 1
                    if healthsick > maxhealth:
                        maxhealth = healthsick
                        breakpoint = row[col]
                HEALTH = [0, 0]
                SICK = [0, 0]

                # Αποθήκευση του αριθμού των συσχετίσεων σε πίνακα για κάθε κλαδί του δένδρου
                for row in BRRAY:
                    if row[col] <= breakpoint:
                        if row[outclass] == healthy:
                            HEALTH[0] += 1
                        if row[outclass] == sick:
                            SICK[0] += 1
                    if row[col] > breakpoint:
                        if row[outclass] == healthy:
                            HEALTH[1] += 1
                        if row[outclass] == sick:
                            SICK[1] += 1

                # Υπολογισμός των μετρικών σε κάθε κλαδεί του δένδρου
                for row in range(0, 2):
                    if HEALTH[row] != 0 or SICK[row] != 0:
                        healthyinfo1 = HEALTH[row] / (HEALTH[row] + SICK[row])
                        sickinfo1 = SICK[row] / (HEALTH[row] + SICK[row])
                        if healthyinfo1 > 0 and sickinfo1 > 0:
                            info1 = -(healthyinfo1 * math.log(healthyinfo1, 2) + sickinfo1 * math.log(sickinfo1, 2))
                        if healthyinfo1 == 0:
                            info1 = -(sickinfo * math.log(sickinfo1, 2))
                        if sickinfo1 == 0:
                            info1 = -(healthyinfo1 * math.log(healthyinfo1, 2))
                        if healthyinfo1 == 0 and sickinfo1 == 0:
                            info1 = 0
                        info2 = (HEALTH[row] + SICK[row]) / (i+1)
                        splitinfo = -(info2 * math.log(info2, 2)) + splitinfo
                        info3 = info3 + info1 * info2   

            else: # Περίπτωση συμβολοσειράς   
                maxcell = 0
                HEALTH = []
                SICK = []
                chunks = 0

                # Διακλάδωση του δένδρου σε τόσα κλαδιά όσες οι διαφορετικές τιμές κλάσης εισόδου
                for row in range(0, i+2):
                    if row < i+1:
                        if maxcell != BRRAY[row][col]:
                            maxcell = BRRAY[row][col]
                            if row > 0:
                                HEALTH.append(healthycount1)
                                SICK.append(sickcount1)
                                chunks += 1
                            healthycount1 = 0
                            sickcount1 = 0
                        if BRRAY[row][outclass] == healthy:
                            healthycount1 += 1
                        if BRRAY[row][outclass] == sick:
                            sickcount1 += 1
                    if row == i+1:
                        HEALTH.append(healthycount1)
                        SICK.append(sickcount1)
                        chunks += 1
                info3 = 0
                splitinfo = 0

                # Υπολογισμός μετρικών
                for row in range(0, chunks):
                        healthyinfo1 = HEALTH[row] / (HEALTH[row] + SICK[row])
                        sickinfo1 = SICK[row] / (HEALTH[row] + SICK[row])
                        if healthyinfo1 > 0 and sickinfo1 > 0:
                            info1 = -(healthyinfo1 * math.log(healthyinfo1, 2) + sickinfo1 * math.log(sickinfo1, 2))
                        if healthyinfo1 == 0:
                            info1 = -(sickinfo * math.log(sickinfo1, 2))
                        if sickinfo1 == 0:
                            info1 = -(healthyinfo1 * math.log(healthyinfo1, 2))
                        if healthyinfo1 == 0 and sickinfo1 == 0:
                            info1 = 0
                        info2 = (HEALTH[row] + SICK[row]) / (i+1)
                        splitinfo = -(info2 * math.log(info2, 2)) + splitinfo
                        info3 = info3 + info1 * info2

            # Εμφάνιση των αποτελεσμάτων μετρικών και αποθήκευση των αποτελεσμάτων για την διακλάδωση του δένδρου
            print()
            HEALTHH.append(HEALTH)
            SICKK.append(SICK)
            print("Info(I) = ", info)
            print("Info(I, ", CRRAY[col],")) = ", info3)
            gain = info - info3
            print("Gain(",CRRAY[col],") = ", gain)
            print("SplitInfo(",CRRAY[col],") = ", splitinfo)
            if splitinfo != 0:
                gainratio = gain / splitinfo
            else:
                gainratio = 0
            print("GainRatio(",CRRAY[col],") = ", gainratio)
            RATIO.append(CRRAY[col])
            GAINRATIO.append(gainratio)
            COL.append(col)
        else:
            HEALTHH.append(0)
            SICKK.append(0)
            
    # Εύρεση της καλύτερης τιμής της Gainratio για την διακλάδωση δένδρου
    maxgain = 0
    maxratio = ''
    root_col = -1
    for row in range(0, number_of_cols-1-rrr):
        if GAINRATIO[row] > maxgain:
            maxgain = GAINRATIO[row]
            maxratio = RATIO[row]
            root_col = COL[row]
    if root_col == -1:
        jjj = 0
        kkk = 0
        for row in BRRAY:
            if row[outclass] == healthy:
                jjj += 1
            if row[outclass] == sick:
                kkk += 1
        print("Το ποσοστό των ζωντανών επιβατών είναι", jjj / (kkk + jjj))
        break
    print("Θέτουμε ως ρίζα την κλάση", maxratio, root_col)

    # Εύρεση του αριθμού των διακλαδώσεων ανά κόμβο 
    COLL.append(root_col)
    ARRAY_SORT(BRRAY, root_col, i)
    rrow = 0
    for row in BRRAY:
        rrow += 1
        
    # Αρχικοποίηση του μεγέθους του αρχείου προς εξέταση στο επόμενο κλαδί
    i = 0
    start = 0
    stop = 0
    healthh = 0
    print(HEALTHH[root_col], SICKK[root_col])
    for row in HEALTHH[root_col]:
        healthh += 1
    for row in range(0, healthh):
        i += HEALTHH[root_col][row]
        i += SICKK[root_col][row]
    
    # Αργικοποίηση των μεταβλητών έναρξης, λήξης του κλαδιού και την ακρίβεια του κλαδιού
    START = []
    STOP = []
    LOGOS = []
    logos = 0.0
    indexx = 0
    
    # Εύρεση του μεγέθους των κλαδιών του δένδρου και την ακρίβεια του
    for row in range(0, healthh):
        if HEALTHH[root_col][row] != 0 and SICKK[root_col][row] != 0:
            start = 0
            if row == 0:
                start = 0
            if row > 0:
                for ccc in range(0, row):
                    start += HEALTHH[root_col][ccc] + SICKK[root_col][ccc]
            stop = HEALTHH[root_col][row] + SICKK[root_col][row] + start
            print(start, stop)
            logos = HEALTHH[root_col][row] / (HEALTHH[root_col][row] + SICKK[root_col][row])
            healtg = ''
            if logos >= 0.5:
                healtg = 'healthy'
            if logos < 0.5:
                logos = 1.0 - logos
                healtg = 'sick'
            print("Το", row, "είναι κλαδί", healtg, "με ακρίβεια", logos)
            START.append(start)
            STOP.append(stop)
            LOGOS.append(logos)
            indexx += 1
        if HEALTHH[root_col][row] == 0 or SICKK[root_col][row] == 0:
            start = 0
            if row == 0:
                start = 0
            if row > 0:
                for ccc in range(0, row):
                    start += HEALTHH[root_col][ccc] + SICKK[root_col][ccc]
            stop = HEALTHH[root_col][row] + SICKK[root_col][row] + start
            print(start, stop)
            logos = 1
            healtg = ''
            if SICKK[root_col][row] == 0:
                healtg = 'healthy'
            if HEALTHH[root_col][row] == 0:
                healtg = 'sick'
            print("Το", row, "είναι", healtg, "φύλλο")
            START.append(start)
            STOP.append(stop)
            LOGOS.append(logos)
            indexx += 1
            
    # Εύρεση του κλαδιού με την μικρότερη ακρίβεια για διακλάδωση
    if START != [] or STOP != [] or LOGOS != []:
        min = 0
        indexxx = 0
        for row in range(0, indexx):
            if row == 0:
                min = LOGOS[row]
            else:
                if LOGOS[row] < min:
                    min = LOGOS[row]
                    indexxx = row
                    
        # Έλεγχος εάν τα παιδιά του κλαδιού είναι φύλλα
        flag = 0
        for row in range(0, indexx):
            if LOGOS[row] != 1:
                flag = 1
        if flag == 1: # Περίπτωση που υπάρχει τουλάχιστον ένα παιδί κλαδί
            print("Το κλαδί που θα εξετάσω είναι το", indexxx, "επειδή έχει μικρότερο λόγο αναλογίας healthy με sick.")
            
            # Επαναπροσδιορισμός του μεγέθους του αρχείου προς εξέταση για το κλαδί που εξετάζουμε
            print(START[indexxx], STOP[indexxx])
            i = STOP[indexxx] - START[indexxx]
            DRRAY = BRRAY
            BRRAY = []
            for row in range(START[indexxx], STOP[indexxx]):
                print(row, DRRAY[row])
                BRRAY.append(DRRAY[row])
        if flag == 0: # Περίπτωση που όλα τα παιδιά είναι φύλλα
            break
    else:
        break
print("Τέλος εκπαίδευσης")

# Το υπόλοιπο 25% του πίνακα ARRAY αποθηκεύεται στον BRRAY για test data set
BRRAY = []
j = 0
k = 0
for row in hARRAY:
    if row != []:
        BRRAY.append(row)
for row in sARRAY:
    if row != []:
        BRRAY.append(row)
llll = 0
print("Ο πίνακας δείγμα είναι")
for row in BRRAY:
    print(llll, row)
    if row[outclass] == healthy:
        j += 1
    if row[outclass] == sick:
        k += 1
    llll += 1
llg = 100 * (j / (k + j))
i = k + j
COLL = []
print()
print("Η αναλογία υγιούς με άρρωστου ασθενή στο training data αρχείο", llg, "%")

# Υπολογισμός της Info της κλάσης εξόδου
for rrr in range(0, number_of_cols - 1):
    # Αρχικοπόηση των πινάκων μετρικών και διακλαδώσεως του δένδρου
    HEALTH = []
    HEALTHH = []
    SICK = []
    SICKK = []
    GAINRATIO = []
    RATIO = []
    COL = []
    i = i - 1
    
    # Υπολογισμός του Info την κλάσης εξόδου
    healthycount = 0
    sickcount = 0
    for row in BRRAY:
        if row[outclass] == healthy:
            healthycount += 1
        if row[outclass] == sick:
            sickcount += 1
    healthyinfo = healthycount / (i+1)
    sickinfo = sickcount / (i+1)
    info = -(healthyinfo * math.log(healthyinfo, 2) + sickinfo * math.log(sickinfo, 2))
    
    # Μέθοδος ταξινόμησης πίνακα με βάση την κλάση εισόδου σε αύξουσα σειρά
    def ARRAY_SORT(BRRAY, index, i):
        for row in range(0, i+1):
            for col in range(0, row+1):
                if BRRAY[row][index] < BRRAY[col][index]:
                    temp = BRRAY[row]
                    BRRAY[row] = BRRAY[col]
                    BRRAY[col] = temp
        
    # Μέθοδος ταξινόμησης της κλάσης εξόδου κατά φθίνουσα σειρά εάν υπάρχουν διαφορετικές τιμές
    # εξόδου στην ίδια τιμή κλάσης εισόδου
    def SORT_ARRAY(BRRAY, index, i):
        flag = 0
        for row in range(0, i+1):
            if BRRAY[row][index] == BRRAY[row - 1][index]:
                if BRRAY[row][outclass] == healthy and BRRAY[row - 1][outclass] == sick:
                    temp = BRRAY[row]
                    BRRAY[row] = BRRAY[row - 1]
                    BRRAY[row - 1] = temp
                flag = 1
            if BRRAY[row][index] != BRRAY[row - 1][index] and flag == 1:
                if BRRAY[row][outclass] == healthy and BRRAY[row- 1][outclass] == sick:
                    temp = BRRAY[row]
                    BRRAY[row] = BRRAY[row - 1]
                    BRRAY[row - 1] = temp
                flag = 0

    # Σύγκριση της κλάσης εξόδου με τις κλάσεις εισόδου
    for col in range(0, number_of_cols):
        # Ελέγχουμε ότι καμία κλάση εισόδου δεν είναι η κλάση εξόδου ή κλάση ρίζα
        if col not in COLL and col != outclass:
            # Ταξινόμηση πίνακα και αρχικοποίηση μεταβλητών διακλάδωσης.
            ARRAY_SORT(BRRAY, col, i)
            SORT_ARRAY(BRRAY, col, i)
            ARRAY_SORT(BRRAY, col, i)
            healthycount1 = 0
            sickcount1 = 0
            info3 = 0
            splitinfo = 0
            
            # Έλεγχος εάν η κλάση εισόδου είναι αριθμός ή συμβολοσειρά.
            flag = BRRAY[1][col]
            if isinstance(flag, int) == True and col != 11 or isinstance(flag, float) == True and col != 1: # Αριθμητική περίπτωση
                healthsick = 0
                maxhealth = 0
                breakpoint = 0

                # Εύρεση της διακλάδωσης του δένδρου
                for row in BRRAY:
                    if row[outclass] == healthy:
                        healthsick += 1
                    if row[outclass] == sick:
                        healthsick -= 1
                    if healthsick > maxhealth:
                        maxhealth = healthsick
                        breakpoint = row[col]
                HEALTH = [0, 0]
                SICK = [0, 0]

                # Αποθήκευση του αριθμού των συσχετίσεων σε πίνακα για κάθε κλαδί του δένδρου
                for row in BRRAY:
                    if row[col] <= breakpoint:
                        if row[outclass] == healthy:
                            HEALTH[0] += 1
                        if row[outclass] == sick:
                            SICK[0] += 1
                    if row[col] > breakpoint:
                        if row[outclass] == healthy:
                            HEALTH[1] += 1
                        if row[outclass] == sick:
                            SICK[1] += 1

                # Υπολογισμός των μετρικών σε κάθε κλαδεί του δένδρου
                for row in range(0, 2):
                    if HEALTH[row] != 0 or SICK[row] != 0:
                        healthyinfo1 = HEALTH[row] / (HEALTH[row] + SICK[row])
                        sickinfo1 = SICK[row] / (HEALTH[row] + SICK[row])
                        if healthyinfo1 > 0 and sickinfo1 > 0:
                            info1 = -(healthyinfo1 * math.log(healthyinfo1, 2) + sickinfo1 * math.log(sickinfo1, 2))
                        if healthyinfo1 == 0:
                            info1 = -(sickinfo * math.log(sickinfo1, 2))
                        if sickinfo1 == 0:
                            info1 = -(healthyinfo1 * math.log(healthyinfo1, 2))
                        if healthyinfo1 == 0 and sickinfo1 == 0:
                            info1 = 0
                        info2 = (HEALTH[row] + SICK[row]) / (i+1)
                        splitinfo = -(info2 * math.log(info2, 2)) + splitinfo
                        info3 = info3 + info1 * info2   

            else: # Περίπτωση συμβολοσειράς   
                maxcell = 0
                HEALTH = []
                SICK = []
                chunks = 0

                # Διακλάδωση του δένδρου σε τόσα κλαδιά όσες οι διαφορετικές τιμές κλάσης εισόδου
                for row in range(0, i+2):
                    if row < i+1:
                        if maxcell != BRRAY[row][col]:
                            maxcell = BRRAY[row][col]
                            if row > 0:
                                HEALTH.append(healthycount1)
                                SICK.append(sickcount1)
                                chunks += 1
                            healthycount1 = 0
                            sickcount1 = 0
                        if BRRAY[row][outclass] == healthy:
                            healthycount1 += 1
                        if BRRAY[row][outclass] == sick:
                            sickcount1 += 1
                    if row == i+1:
                        HEALTH.append(healthycount1)
                        SICK.append(sickcount1)
                        chunks += 1
                info3 = 0
                splitinfo = 0

                # Υπολογισμός μετρικών
                for row in range(0, chunks):
                        healthyinfo1 = HEALTH[row] / (HEALTH[row] + SICK[row])
                        sickinfo1 = SICK[row] / (HEALTH[row] + SICK[row])
                        if healthyinfo1 > 0 and sickinfo1 > 0:
                            info1 = -(healthyinfo1 * math.log(healthyinfo1, 2) + sickinfo1 * math.log(sickinfo1, 2))
                        if healthyinfo1 == 0:
                            info1 = -(sickinfo * math.log(sickinfo1, 2))
                        if sickinfo1 == 0:
                            info1 = -(healthyinfo1 * math.log(healthyinfo1, 2))
                        if healthyinfo1 == 0 and sickinfo1 == 0:
                            info1 = 0
                        info2 = (HEALTH[row] + SICK[row]) / (i+1)
                        splitinfo = -(info2 * math.log(info2, 2)) + splitinfo
                        info3 = info3 + info1 * info2

            # Εμφάνιση των αποτελεσμάτων μετρικών και αποθήκευση των αποτελεσμάτων για την διακλάδωση του δένδρου
            print()
            HEALTHH.append(HEALTH)
            SICKK.append(SICK)
            print("Info(I) = ", info)
            print("Info(I, ", CRRAY[col],")) = ", info3)
            gain = info - info3
            print("Gain(",CRRAY[col],") = ", gain)
            print("SplitInfo(",CRRAY[col],") = ", splitinfo)
            if splitinfo != 0:
                gainratio = gain / splitinfo
            else:
                gainratio = 0
            print("GainRatio(",CRRAY[col],") = ", gainratio)
            RATIO.append(CRRAY[col])
            GAINRATIO.append(gainratio)
            COL.append(col)
        else:
            HEALTHH.append(0)
            SICKK.append(0)
            
    # Εύρεση της καλύτερης τιμής της Gainratio για την διακλάδωση δένδρου
    maxgain = 0
    maxratio = ''
    root_col = -1
    for row in range(0, number_of_cols-1-rrr):
        if GAINRATIO[row] > maxgain:
            maxgain = GAINRATIO[row]
            maxratio = RATIO[row]
            root_col = COL[row]
    if root_col == -1:
        jjj = 0
        kkk = 0
        for row in BRRAY:
            if row[outclass] == healthy:
                jjj += 1
            if row[outclass] == sick:
                kkk += 1
        print("Το ποσοστό των ζωντανών επιβατών είναι", jjj / (kkk + jjj))
        break
    print("Θέτουμε ως ρίζα την κλάση", maxratio, root_col)

    # Εύρεση του αριθμού των διακλαδώσεων ανά κόμβο 
    COLL.append(root_col)
    ARRAY_SORT(BRRAY, root_col, i)
    rrow = 0
    for row in BRRAY:
        rrow += 1
        
    # Αρχικοποίηση του μεγέθους του αρχείου προς εξέταση στο επόμενο κλαδί
    i = 0
    start = 0
    stop = 0
    healthh = 0
    print(HEALTHH[root_col], SICKK[root_col])
    for row in HEALTHH[root_col]:
        healthh += 1
    for row in range(0, healthh):
        i += HEALTHH[root_col][row]
        i += SICKK[root_col][row]
    
    # Αργικοποίηση των μεταβλητών έναρξης, λήξης του κλαδιού και την ακρίβεια του κλαδιού
    START = []
    STOP = []
    LOGOS = []
    logos = 0.0
    indexx = 0
    
    # Εύρεση του μεγέθους των κλαδιών του δένδρου και την ακρίβεια του
    for row in range(0, healthh):
        if HEALTHH[root_col][row] != 0 and SICKK[root_col][row] != 0:
            start = 0
            if row == 0:
                start = 0
            if row > 0:
                for ccc in range(0, row):
                    start += HEALTHH[root_col][ccc] + SICKK[root_col][ccc]
            stop = HEALTHH[root_col][row] + SICKK[root_col][row] + start
            print(start, stop)
            logos = HEALTHH[root_col][row] / (HEALTHH[root_col][row] + SICKK[root_col][row])
            healtg = ''
            if logos >= 0.5:
                healtg = 'healthy'
            if logos < 0.5:
                logos = 1.0 - logos
                healtg = 'sick'
            print("Το", row, "είναι κλαδί", healtg, "με ακρίβεια", logos)
            START.append(start)
            STOP.append(stop)
            LOGOS.append(logos)
            indexx += 1
        if HEALTHH[root_col][row] == 0 or SICKK[root_col][row] == 0:
            start = 0
            if row == 0:
                start = 0
            if row > 0:
                for ccc in range(0, row):
                    start += HEALTHH[root_col][ccc] + SICKK[root_col][ccc]
            stop = HEALTHH[root_col][row] + SICKK[root_col][row] + start
            print(start, stop)
            logos = 1
            healtg = ''
            if SICKK[root_col][row] == 0:
                healtg = 'healthy'
            if HEALTHH[root_col][row] == 0:
                healtg = 'sick'
            print("Το", row, "είναι", healtg, "φύλλο")
            START.append(start)
            STOP.append(stop)
            LOGOS.append(logos)
            indexx += 1
            
    # Εύρεση του κλαδιού με την μικρότερη ακρίβεια για διακλάδωση
    if START != [] or STOP != [] or LOGOS != []:
        min = 0
        indexxx = 0
        for row in range(0, indexx):
            if row == 0:
                min = LOGOS[row]
            else:
                if LOGOS[row] < min:
                    min = LOGOS[row]
                    indexxx = row
                    
        # Έλεγχος εάν τα παιδιά του κλαδιού είναι φύλλα
        flag = 0
        for row in range(0, indexx):
            if LOGOS[row] != 1:
                flag = 1
        if flag == 1: # Περίπτωση που υπάρχει τουλάχιστον ένα παιδί κλαδί
            print("Το κλαδί που θα εξετάσω είναι το", indexxx, "επειδή έχει μικρότερο λόγο αναλογίας healthy με sick.")
            
            # Επαναπροσδιορισμός του μεγέθους του αρχείου προς εξέταση για το κλαδί που εξετάζουμε
            print(START[indexxx], STOP[indexxx])
            i = STOP[indexxx] - START[indexxx]
            DRRAY = BRRAY
            BRRAY = []
            for row in range(START[indexxx], STOP[indexxx]):
                print(row, DRRAY[row])
                BRRAY.append(DRRAY[row])
        if flag == 0: # Περίπτωση που όλα τα παιδιά είναι φύλλα
            break
    else:
        break
print("Τέλος")